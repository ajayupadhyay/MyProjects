package com.rbc.prog.test;

import java.io.File;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rbc.prog.FileReadWriteProcessor;

/**
 * This class is responsible for test FileReadWriteProcessor.
 * @author ajay
 *
 */
public class FileReadWriteProcessorTest {

	@Before
	public void setUp() throws Exception {
	}

	/**
	 * 
	 */
	@Test
	public void testReverseFile() {
		FileReadWriteProcessor fileReadWriteProcessor = new FileReadWriteProcessor();
		fileReadWriteProcessor.reverseFile(new File("/test.psv"),
				new File("/test.csv"), "LastName");
		Assert.assertTrue(true);
	}

	/**
	 * 
	 */
	@Test
	public void testReverseFileWhenColumnToRemoveIsNull() {
		FileReadWriteProcessor fileReadWriteProcessor = new FileReadWriteProcessor();
		fileReadWriteProcessor.reverseFile(new File("/test.psv"),
				new File("/test.csv"), null);
		Assert.assertTrue(true);
	}
	
	/**
	 * 
	 */
	@Test
	public void testReverseFileWhenInputFileNull() {
		FileReadWriteProcessor fileReadWriteProcessor = new FileReadWriteProcessor();
		fileReadWriteProcessor.reverseFile(null,
				new File("/test.csv"), null);
		Assert.assertTrue(true);
	}
}
