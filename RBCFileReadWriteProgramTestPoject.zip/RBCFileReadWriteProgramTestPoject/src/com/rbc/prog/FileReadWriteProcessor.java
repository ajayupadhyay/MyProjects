package com.rbc.prog;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class is responsible for read, write and reverse of file content.
 * 
 * @author ajay
 * 
 */
public class FileReadWriteProcessor {

	private static final String PSV_FILE_DELIMITER = "\\|";
	private static final String CSV_FILE_DELIMITER_COMMA = ",";
	private static final String BLANK = "";

	/**
	 * This method perform read, write, remove and reverse operation on file
	 * content.
	 * 
	 * @param inputPsvFile
	 * @param outputCsvFile
	 * @param columnToRemove
	 */
	public final void reverseFile(File inputPsvFile, File outputCsvFile,
			String columnToRemove) {

		String thisLine = null;
		Integer index = null;
		// below variable just defining for printing the column/row count, it
		// can be removed
		int columnsRead = 0;
		int columnsOutput = 0;

		// using java1.7 try with resource feature which will close the
		// connection.
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(
				inputPsvFile));
				BufferedWriter bufferedWriter = new BufferedWriter(
						new FileWriter(outputCsvFile));) {
			ArrayList<String> inputStrList = new ArrayList<String>();
			// Open input stream test.psv for reading purpose.
			while ((thisLine = bufferedReader.readLine()) != null) {
				inputStrList.add(thisLine);
			}
			// implementing remove column and reverse column logic
			for (String strTemp : inputStrList) {
				String tempInputColumnArr[] = strTemp.split(PSV_FILE_DELIMITER);
				// List<String> tempList = Arrays.asList(temp);
				List<String> tempInputColumnList = new ArrayList<String>();
				for (String tempstr : tempInputColumnArr)
					tempInputColumnList.add(tempstr);
				columnsRead = tempInputColumnList.size();
				// finding the index for removing the column for parameter
				// columnToRemove.
				if ((null != columnToRemove && !(columnToRemove.trim().equals(BLANK)))
						&& (null == index)) {
					index = 0;
					for (String strTemp2 : tempInputColumnList) {
						if (strTemp2.equals(columnToRemove)) {							
							break;
						}
						index++;
					}
				}
				// removing the column from list.
				columnsOutput = tempInputColumnList.size();
				if (null != index) {
					tempInputColumnList.remove(index.intValue());
					columnsOutput = tempInputColumnList.size() - 1;
				}
				
				// revering the columns from list.
				Collections.reverse(tempInputColumnList);
				// writing the content to test.csv file.
				StringBuilder tempStringBuilder = new StringBuilder();
				for (String wrStr : tempInputColumnList) {
					tempStringBuilder.append(wrStr);
					tempStringBuilder.append(CSV_FILE_DELIMITER_COMMA);
				}
				bufferedWriter.write(tempStringBuilder.toString());
				bufferedWriter.newLine();
				bufferedWriter.flush();
			}
			System.out.println("No. of columns read : " + columnsRead);
			System.out.println("No. of columns output: " + columnsOutput
					+ ", The column '" + columnToRemove
					+ "' has been removed from output.");
			System.out
					.println("No. of rows read: " + (inputStrList.size() - 1));
			System.out.println("No. of rows output: "
					+ (inputStrList.size() - 1));

		} catch (IOException | NullPointerException exception) {
			exception.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
}