/**
 * 
 */
package com.rbc.prog.test;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.rbc.prog.BasketItemsCostCalculator;
import com.rbc.prog.vo.Bananas;
import com.rbc.prog.vo.Fruit;
import com.rbc.prog.vo.Oranges;

/**
 * @author ajay
 * 
 */
public class BasketItemsCostCalculatorTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for
	 * {@link com.rbc.prog.BasketItemsCostCalculator#getBasketOfItemsTotalCost(java.util.List)}
	 * .
	 */
	@Test
	public void testGetBasketOfItemsTotalCost() {
		List<Fruit> fruitsList = new ArrayList<Fruit>();
		Bananas bananas = new Bananas();
		bananas.setCost(250);
		bananas.setName("Bananas");
		Oranges oranges = new Oranges();
		oranges.setCost(300);
		oranges.setName("Oranges");
		fruitsList.add(bananas);
		fruitsList.add(oranges);
		BasketItemsCostCalculator basketItemsCostCalculator = new BasketItemsCostCalculator();
		Assert.assertNotNull(basketItemsCostCalculator
				.getBasketOfItemsTotalCost(fruitsList));
	}

}
