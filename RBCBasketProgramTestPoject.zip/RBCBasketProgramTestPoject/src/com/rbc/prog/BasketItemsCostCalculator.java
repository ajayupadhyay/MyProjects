package com.rbc.prog;

import java.util.List;

import com.rbc.prog.vo.Fruit;

/**
 * @author ajay
 * This class is responsible for calculating total cost of basket of items.
 *
 */
public class BasketItemsCostCalculator {

	/**
	 * @param fruitsList
	 * @return
	 */
	public final float getBasketOfItemsTotalCost(
			List<? extends Fruit> fruitsList) {
		float totalCost = 0;
		for (Fruit fruit : fruitsList) {
			totalCost = totalCost + fruit.getCost();
		}
		System.out.println("Total Cost: " + totalCost);
		return totalCost;
	}
}
