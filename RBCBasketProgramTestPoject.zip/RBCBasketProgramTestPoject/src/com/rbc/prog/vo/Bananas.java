package com.rbc.prog.vo;

public class Bananas implements Fruit {
	private String name;
	private float cost;
	
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param cost the cost to set
	 */
	public void setCost(float cost) {
		this.cost = cost;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public float getCost() {
		// TODO Auto-generated method stub
		return cost;
	}
}
