/**
 * 
 */
package com.rbc.prog.vo;

/**
 * @author ajay0707
 *
 */
public interface Fruit {
	public String getName();
	public float getCost();
}
